// import display from "./display";

// place your code on line 5 above the export statement below

class Snake {}

export default Snake;
