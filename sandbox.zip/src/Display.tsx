import "./Display.css";

export default function Display() {
  return (
    <pre id="output">
      OUTPUT: <br />
    </pre>
  );
}
