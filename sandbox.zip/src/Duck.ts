import display from "./display";
// import IQuacker from "./IQuacker";

// place your code on line 5 above the export statement below
class Duck {
    public quackCount: number;
    public color: string;
    constructor(duckColor: string) {
      this.quackCount = 0;
      this.color = duckColor;
    }
    quack(quack: number) {
      display("The", this.color, "duck says QUACK!!!");
      this.quackCount = this.quackCount + quack;
    }
}  

export default Duck;